from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, Response
from pydantic import BaseModel
from typing import List, Optional
from pathlib import Path
from urllib.parse import parse_qs
import base64, hashlib, hmac, json, os, secrets, sqlite3, time, uuid
from datetime import datetime
from openpyxl import Workbook

BASE=Path(__file__).resolve().parent; DB=BASE/'ernte.db'; WEB=BASE/'web'; EXPORT=BASE/'ernte_export.xlsx'; AUTH=BASE/'auth.env'
if AUTH.exists():
    for raw in AUTH.read_text(encoding='utf-8-sig').splitlines():
        if '=' in raw and not raw.lstrip().startswith('#'):
            key,value=raw.split('=',1); os.environ.setdefault(key.strip(),value.strip())
USER=os.getenv('ERNTE_USER','Admin'); PASSWORD=os.getenv('ERNTE_PASSWORD',''); SECRET=os.getenv('ERNTE_SECRET',hashlib.sha256((PASSWORD+str(BASE)).encode()).hexdigest()); SCALE_TOKEN=os.getenv('WAAGE_TOKEN','')
COOKIE='ernte_session'; MAX_AGE=60*60*24*30
app=FastAPI(docs_url=None,redoc_url=None,openapi_url=None)

class Entry(BaseModel):
    id:str; date:str; crop:str; amount_a:float=0; amount_b:float=0; start:str; end:str; staff:int=0; updated_at:str; deleted:bool=False
    class1_boxes:int=0; class1_trays:int=0; raw_total:float=0; employee_ids:List[int]=[]
class SyncPayload(BaseModel):
    entries:List[Entry]; since:Optional[str]=None
class ScaleEvent(BaseModel):
    weight:float; stable:bool=True; station:str='waage-1'; event_id:Optional[str]=None
class EmployeeArm(BaseModel):
    employee_number:str; station:str='waage-1'
class NfcEvent(BaseModel):
    uid:str; station:str='waage-1'
class NfcAssignment(BaseModel):
    uid:str; employee_number:str; station:str='waage-1'
class EmployeePayload(BaseModel):
    number:str; name:str; active:bool=True
class PasskeyRegister(BaseModel):
    challenge_id:str; credential_id:str; client_data:str; public_key:str; name:str='iPhone'
class PasskeyLogin(BaseModel):
    challenge_id:str; credential_id:str; client_data:str; authenticator_data:str; signature:str

def b64e(data:bytes): return base64.urlsafe_b64encode(data).rstrip(b'=').decode()
def b64d(value:str): return base64.urlsafe_b64decode(value+'='*((4-len(value)%4)%4))

def conn():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init_db():
    with conn() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS entries (id TEXT PRIMARY KEY,date TEXT NOT NULL,crop TEXT NOT NULL,amount_a REAL NOT NULL DEFAULT 0,amount_b REAL NOT NULL DEFAULT 0,start TEXT NOT NULL,end TEXT NOT NULL,staff INTEGER NOT NULL,updated_at TEXT NOT NULL,deleted INTEGER NOT NULL DEFAULT 0)''')
        c.execute('''CREATE TABLE IF NOT EXISTS raw_weighings (id TEXT PRIMARY KEY,work_date TEXT NOT NULL,weight REAL NOT NULL,employee_number TEXT,station TEXT NOT NULL,created_at TEXT NOT NULL,deleted INTEGER NOT NULL DEFAULT 0)''')
        columns={row[1] for row in c.execute('PRAGMA table_info(raw_weighings)')}
        if 'employee_number' not in columns: c.execute('ALTER TABLE raw_weighings ADD COLUMN employee_number TEXT')
        c.execute('''CREATE TABLE IF NOT EXISTS scale_station_state (station TEXT PRIMARY KEY,pending_employee TEXT,armed_at TEXT)''')
        state_columns={row[1] for row in c.execute('PRAGMA table_info(scale_station_state)')}
        if 'last_card_uid' not in state_columns: c.execute('ALTER TABLE scale_station_state ADD COLUMN last_card_uid TEXT')
        if 'card_status' not in state_columns: c.execute('ALTER TABLE scale_station_state ADD COLUMN card_status TEXT')
        if 'card_seen_at' not in state_columns: c.execute('ALTER TABLE scale_station_state ADD COLUMN card_seen_at TEXT')
        c.execute('''CREATE TABLE IF NOT EXISTS employee_cards (uid TEXT PRIMARY KEY,employee_number TEXT NOT NULL,created_at TEXT NOT NULL)''')
        for name,kind,default in [('class1_boxes','INTEGER','0'),('class1_trays','INTEGER','0'),('raw_total','REAL','0')]:
            if name not in {r[1] for r in c.execute('PRAGMA table_info(entries)')}: c.execute(f'ALTER TABLE entries ADD COLUMN {name} {kind} NOT NULL DEFAULT {default}')
        c.execute('''CREATE TABLE IF NOT EXISTS employees(id INTEGER PRIMARY KEY AUTOINCREMENT,number TEXT NOT NULL UNIQUE,name TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,deleted INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL)''')
        c.execute('''CREATE TABLE IF NOT EXISTS entry_employees(entry_id TEXT NOT NULL,employee_id INTEGER NOT NULL,PRIMARY KEY(entry_id,employee_id))''')
        c.execute('''CREATE TABLE IF NOT EXISTS passkeys(credential_id TEXT PRIMARY KEY,public_key TEXT NOT NULL,name TEXT NOT NULL,sign_count INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL)''')
        c.execute('''CREATE TABLE IF NOT EXISTS passkey_challenges(id TEXT PRIMARY KEY,challenge TEXT NOT NULL,purpose TEXT NOT NULL,expires_at INTEGER NOT NULL)''')
@app.on_event('startup')
def startup(): init_db()
def token():
    expiry=str(int(time.time())+MAX_AGE); sig=hmac.new(SECRET.encode(),f'{USER}:{expiry}'.encode(),hashlib.sha256).hexdigest(); return f'{expiry}.{sig}'
def is_auth(request:Request):
    try:
        expiry,sig=request.cookies.get(COOKIE,'').split('.',1); expected=hmac.new(SECRET.encode(),f'{USER}:{expiry}'.encode(),hashlib.sha256).hexdigest(); return int(expiry)>=int(time.time()) and hmac.compare_digest(sig,expected)
    except (ValueError,TypeError): return False
def require(request:Request):
    if not is_auth(request): raise HTTPException(401,'Anmeldung erforderlich')
def private(response:Response):
    response.headers['Cache-Control']='no-store, private'; response.headers['X-Frame-Options']='DENY'; response.headers['X-Content-Type-Options']='nosniff'; response.headers['Referrer-Policy']='no-referrer'; return response

@app.get('/')
def landing(request:Request):
    return RedirectResponse('/app',303) if is_auth(request) else FileResponse(WEB/'landing.html')
@app.get('/logo')
def logo(): return FileResponse(WEB/'logo.jpg',media_type='image/jpeg')
@app.get('/login')
def login_page(request:Request):
    return RedirectResponse('/app',303) if is_auth(request) else private(FileResponse(WEB/'login.html'))
@app.post('/login')
async def login(request:Request):
    form=parse_qs((await request.body()).decode('utf-8','replace')); username=form.get('username',[''])[0]; password=form.get('password',[''])[0]
    if not(hmac.compare_digest(username,USER) and hmac.compare_digest(password,PASSWORD)): return RedirectResponse('/login?fehler=1',303)
    response=RedirectResponse('/app',303); response.set_cookie(COOKIE,token(),max_age=MAX_AGE,httponly=True,secure=request.url.scheme=='https',samesite='strict',path='/'); return private(response)
@app.post('/logout')
def logout():
    response=RedirectResponse('/',303); response.delete_cookie(COOKIE,path='/'); return private(response)
@app.get('/app')
def internal(request:Request):
    return private(FileResponse(WEB/'app.html')) if is_auth(request) else RedirectResponse('/login',303)
@app.get('/manifest.webmanifest')
def manifest(request:Request):
    require(request); return private(FileResponse(WEB/'manifest.webmanifest',media_type='application/manifest+json'))
@app.get('/api/health')
def health(request:Request):
    require(request); return private(JSONResponse({'ok':True,'time':datetime.utcnow().isoformat()+'Z'}))
@app.get('/api/employees')
def employees(request:Request,include_inactive:bool=True):
    require(request)
    with conn() as c: rows=c.execute('''SELECT e.id,e.number,e.name,e.active,COUNT(ec.uid) card_count FROM employees e LEFT JOIN employee_cards ec ON ec.employee_number=e.number WHERE e.deleted=0 '''+('' if include_inactive else 'AND e.active=1 ')+'''GROUP BY e.id,e.number,e.name,e.active ORDER BY CAST(e.number AS INTEGER),e.number''').fetchall()
    return private(JSONResponse({'employees':[dict(r)|{'active':bool(r['active'])} for r in rows]}))
@app.post('/api/employees')
def create_employee(payload:EmployeePayload,request:Request):
    require(request); number=payload.number.strip(); name=payload.name.strip()
    if not number.isdigit() or len(number)>20 or not name or len(name)>100: raise HTTPException(400,'Nummer oder Name ungültig')
    try:
        with conn() as c:
            cur=c.execute('INSERT INTO employees(number,name,active,deleted,created_at) VALUES(?,?,?,0,?)',(number,name,1 if payload.active else 0,datetime.now().isoformat(timespec='seconds'))); employee_id=cur.lastrowid
    except sqlite3.IntegrityError: raise HTTPException(409,'Mitarbeiternummer bereits vergeben')
    return private(JSONResponse({'ok':True,'id':employee_id}))
@app.put('/api/employees/{employee_id}')
def update_employee(employee_id:int,payload:EmployeePayload,request:Request):
    require(request); number=payload.number.strip(); name=payload.name.strip()
    if not number.isdigit() or not name: raise HTTPException(400,'Nummer oder Name ungültig')
    try:
        with conn() as c:
            old=c.execute('SELECT number FROM employees WHERE id=? AND deleted=0',(employee_id,)).fetchone();c.execute('UPDATE employees SET number=?,name=?,active=? WHERE id=? AND deleted=0',(number,name,1 if payload.active else 0,employee_id))
            if old and old['number']!=number:c.execute('UPDATE employee_cards SET employee_number=? WHERE employee_number=?',(number,old['number']))
    except sqlite3.IntegrityError: raise HTTPException(409,'Mitarbeiternummer bereits vergeben')
    return private(JSONResponse({'ok':True}))
@app.delete('/api/employees/{employee_id}')
def delete_employee(employee_id:int,request:Request):
    require(request)
    with conn() as c: c.execute('UPDATE employees SET deleted=1,active=0 WHERE id=?',(employee_id,))
    return private(JSONResponse({'ok':True}))

def new_challenge(purpose):
    cid=secrets.token_urlsafe(18); challenge=b64e(secrets.token_bytes(32))
    with conn() as c:
        c.execute('DELETE FROM passkey_challenges WHERE expires_at<?',(int(time.time()),)); c.execute('INSERT INTO passkey_challenges VALUES(?,?,?,?)',(cid,challenge,purpose,int(time.time())+300))
    return cid,challenge
def take_challenge(cid,purpose):
    with conn() as c:
        row=c.execute('SELECT challenge FROM passkey_challenges WHERE id=? AND purpose=? AND expires_at>=?',(cid,purpose,int(time.time()))).fetchone(); c.execute('DELETE FROM passkey_challenges WHERE id=?',(cid,))
    if not row: raise HTTPException(400,'Anmeldeanforderung abgelaufen')
    return row['challenge']
def valid_client(client_b64,challenge,kind,request):
    try:
        data=json.loads(b64d(client_b64)); expected=f'{request.url.scheme}://{request.url.netloc}'
        return data.get('type')==kind and data.get('challenge')==challenge and data.get('origin')==expected
    except: return False
P=0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff; A=P-3; B=0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b; N=0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551; G=(0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296,0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5)
def addpt(p,q):
    if p is None:return q
    if q is None:return p
    if p[0]==q[0] and (p[1]+q[1])%P==0:return None
    m=((3*p[0]*p[0]+A)*pow(2*p[1],-1,P) if p==q else (q[1]-p[1])*pow(q[0]-p[0],-1,P))%P; x=(m*m-p[0]-q[0])%P; return x,(m*(p[0]-x)-p[1])%P
def mul(k,p):
    r=None
    while k:
        if k&1:r=addpt(r,p)
        p=addpt(p,p);k>>=1
    return r
def der_sig(sig):
    if len(sig)<8 or sig[0]!=0x30: raise ValueError()
    i=2
    if sig[1]&128:i=2+(sig[1]&127)
    if sig[i]!=2:raise ValueError()
    lr=sig[i+1];r=int.from_bytes(sig[i+2:i+2+lr],'big');i+=2+lr
    if sig[i]!=2:raise ValueError()
    ls=sig[i+1];s=int.from_bytes(sig[i+2:i+2+ls],'big');return r,s
def verify_es256(public_der,message,signature):
    try:
        point=public_der[-65:]; q=(int.from_bytes(point[1:33],'big'),int.from_bytes(point[33:],'big'));r,s=der_sig(signature)
        if point[0]!=4 or not(0<r<N and 0<s<N):return False
        z=int.from_bytes(hashlib.sha256(message).digest(),'big');w=pow(s,-1,N);x=addpt(mul((z*w)%N,G),mul((r*w)%N,q));return x is not None and x[0]%N==r
    except:return False
@app.post('/api/passkeys/register/options')
def passkey_reg_options(request:Request):
    require(request);cid,ch=new_challenge('register')
    return private(JSONResponse({'challenge_id':cid,'publicKey':{'challenge':ch,'rp':{'name':'Hirschmann Beeren KG'},'user':{'id':b64e(hashlib.sha256(USER.encode()).digest()[:16]),'name':USER,'displayName':USER},'pubKeyCredParams':[{'type':'public-key','alg':-7}],'authenticatorSelection':{'authenticatorAttachment':'platform','residentKey':'required','userVerification':'required'},'timeout':60000,'attestation':'none'}}))
@app.post('/api/passkeys/register')
def passkey_register(payload:PasskeyRegister,request:Request):
    require(request);challenge=take_challenge(payload.challenge_id,'register')
    if not valid_client(payload.client_data,challenge,'webauthn.create',request):raise HTTPException(400,'Passkey konnte nicht geprüft werden')
    public=b64d(payload.public_key)
    if len(public)<65 or public[-65]!=4:raise HTTPException(400,'Nicht unterstützter Passkey')
    with conn() as c:c.execute('INSERT OR REPLACE INTO passkeys(credential_id,public_key,name,created_at) VALUES(?,?,?,?)',(payload.credential_id,b64e(public),payload.name[:80],datetime.now().isoformat(timespec='seconds')))
    return private(JSONResponse({'ok':True}))
@app.post('/api/passkeys/login/options')
def passkey_login_options():
    cid,ch=new_challenge('login');return private(JSONResponse({'challenge_id':cid,'publicKey':{'challenge':ch,'timeout':60000,'userVerification':'required'}}))
@app.post('/api/passkeys/login')
def passkey_login(payload:PasskeyLogin,request:Request):
    challenge=take_challenge(payload.challenge_id,'login')
    if not valid_client(payload.client_data,challenge,'webauthn.get',request):raise HTTPException(401,'Passkey ungültig')
    with conn() as c: row=c.execute('SELECT public_key FROM passkeys WHERE credential_id=?',(payload.credential_id,)).fetchone()
    if not row:raise HTTPException(401,'Passkey unbekannt')
    auth=b64d(payload.authenticator_data);client=b64d(payload.client_data)
    if len(auth)<37 or auth[:32]!=hashlib.sha256(request.url.hostname.encode()).digest() or not(auth[32]&4) or not verify_es256(b64d(row['public_key']),auth+hashlib.sha256(client).digest(),b64d(payload.signature)):raise HTTPException(401,'Face ID konnte nicht bestätigt werden')
    response=private(JSONResponse({'ok':True}));response.set_cookie(COOKIE,token(),max_age=MAX_AGE,httponly=True,secure=request.url.scheme=='https',samesite='strict',path='/');return response
@app.post('/api/scale/stable')
def stable_weight(event:ScaleEvent,request:Request):
    supplied=request.headers.get('x-scale-token','')
    if not is_auth(request) and not(SCALE_TOKEN and hmac.compare_digest(supplied,SCALE_TOKEN)): raise HTTPException(401,'Waagenzugriff nicht erlaubt')
    if not event.stable: return private(JSONResponse({'accepted':False,'reason':'not_stable'}))
    if event.weight<=0 or event.weight>500: raise HTTPException(400,'Ungültiges Gewicht')
    now=datetime.now(); work_date=now.date().isoformat(); created=now.isoformat(timespec='seconds'); event_id=event.event_id or str(uuid.uuid4())
    with conn() as c:
        state=c.execute('SELECT pending_employee FROM scale_station_state WHERE station=?',(event.station,)).fetchone()
        employee=(state['pending_employee'] or '').strip() if state else ''
        if not employee: return private(JSONResponse({'accepted':False,'reason':'employee_required'}))
        duplicate=c.execute('SELECT id FROM raw_weighings WHERE station=? AND ABS(weight-?)<0.001 AND created_at>=? AND deleted=0',(event.station,event.weight,datetime.fromtimestamp(now.timestamp()-5).isoformat(timespec='seconds'))).fetchone()
        if duplicate: return private(JSONResponse({'accepted':False,'reason':'duplicate'}))
        cursor=c.execute('INSERT OR IGNORE INTO raw_weighings(id,work_date,weight,employee_number,station,created_at,deleted) VALUES(?,?,?,?,?,?,0)',(event_id,work_date,round(event.weight,3),employee,event.station[:80],created))
        if cursor.rowcount: c.execute('UPDATE scale_station_state SET pending_employee=NULL,armed_at=NULL WHERE station=?',(event.station,))
        row=c.execute('SELECT COUNT(*) count,COALESCE(SUM(weight),0) total FROM raw_weighings WHERE work_date=? AND deleted=0',(work_date,)).fetchone()
    return private(JSONResponse({'accepted':True,'weight':round(event.weight,3),'employee_number':employee,'count':row['count'],'total':round(row['total'],3),'work_date':work_date}))
@app.post('/api/raw/arm')
def arm_employee(payload:EmployeeArm,request:Request):
    require(request); employee=payload.employee_number.strip()
    if not employee.isdigit() or len(employee)>20: raise HTTPException(400,'Mitarbeiternummer muss aus Ziffern bestehen')
    with conn() as c:
        known=c.execute('SELECT id FROM employees WHERE number=? AND active=1 AND deleted=0',(employee,)).fetchone()
    if not known: raise HTTPException(400,'Mitarbeiter ist nicht aktiv oder unbekannt')
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c: c.execute('INSERT INTO scale_station_state(station,pending_employee,armed_at) VALUES(?,?,?) ON CONFLICT(station) DO UPDATE SET pending_employee=excluded.pending_employee,armed_at=excluded.armed_at',(payload.station[:80],employee,now))
    return private(JSONResponse({'ok':True,'station':payload.station,'employee_number':employee}))
@app.post('/api/nfc/card')
def nfc_card(payload:NfcEvent,request:Request):
    supplied=request.headers.get('x-scale-token','')
    if not is_auth(request) and not(SCALE_TOKEN and hmac.compare_digest(supplied,SCALE_TOKEN)): raise HTTPException(401,'NFC-Zugriff nicht erlaubt')
    uid=''.join(ch for ch in payload.uid.upper() if ch in '0123456789ABCDEF')
    if len(uid)<8 or len(uid)>32: raise HTTPException(400,'Ungültige Kartenkennung')
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        card=c.execute('SELECT ec.employee_number FROM employee_cards ec JOIN employees e ON e.number=ec.employee_number WHERE ec.uid=? AND e.active=1 AND e.deleted=0',(uid,)).fetchone()
        employee=card['employee_number'] if card else None; status='assigned' if employee else 'unassigned'
        c.execute('''INSERT INTO scale_station_state(station,pending_employee,armed_at,last_card_uid,card_status,card_seen_at) VALUES(?,?,?,?,?,?) ON CONFLICT(station) DO UPDATE SET pending_employee=excluded.pending_employee,armed_at=excluded.armed_at,last_card_uid=excluded.last_card_uid,card_status=excluded.card_status,card_seen_at=excluded.card_seen_at''',(payload.station[:80],employee,now if employee else None,uid,status,now))
    return private(JSONResponse({'ok':True,'status':status,'employee_number':employee,'uid_suffix':uid[-6:]}))
@app.post('/api/nfc/assign')
def assign_nfc(payload:NfcAssignment,request:Request):
    require(request); uid=''.join(ch for ch in payload.uid.upper() if ch in '0123456789ABCDEF'); employee=payload.employee_number.strip()
    if len(uid)<8 or len(uid)>32: raise HTTPException(400,'Ungültige Kartenkennung')
    if not employee.isdigit() or len(employee)>20: raise HTTPException(400,'Mitarbeiternummer muss aus Ziffern bestehen')
    with conn() as c:
        if not c.execute('SELECT id FROM employees WHERE number=? AND active=1 AND deleted=0',(employee,)).fetchone(): raise HTTPException(400,'Mitarbeiter ist nicht aktiv oder unbekannt')
    now=datetime.now().isoformat(timespec='seconds')
    with conn() as c:
        c.execute('INSERT INTO employee_cards(uid,employee_number,created_at) VALUES(?,?,?) ON CONFLICT(uid) DO UPDATE SET employee_number=excluded.employee_number',(uid,employee,now))
        c.execute('''INSERT INTO scale_station_state(station,pending_employee,armed_at,last_card_uid,card_status) VALUES(?,?,?,?,?) ON CONFLICT(station) DO UPDATE SET pending_employee=excluded.pending_employee,armed_at=excluded.armed_at,last_card_uid=excluded.last_card_uid,card_status=excluded.card_status''',(payload.station[:80],employee,now,uid,'assigned'))
    return private(JSONResponse({'ok':True,'employee_number':employee}))
@app.get('/api/raw/today')
def raw_today(request:Request,day:Optional[str]=None,station:str='waage-1'):
    require(request); selected=day or datetime.now().date().isoformat()
    with conn() as c:
        rows=c.execute('SELECT id,weight,employee_number,station,created_at FROM raw_weighings WHERE work_date=? AND deleted=0 ORDER BY created_at DESC LIMIT 100',(selected,)).fetchall()
        total=c.execute('SELECT COUNT(*) count,COALESCE(SUM(weight),0) total,MIN(created_at) first_at FROM raw_weighings WHERE work_date=? AND deleted=0',(selected,)).fetchone()
        state=c.execute('SELECT pending_employee,armed_at,last_card_uid,card_status,card_seen_at FROM scale_station_state WHERE station=?',(station,)).fetchone()
    last=dict(rows[0]) if rows else None
    return private(JSONResponse({'work_date':selected,'count':total['count'],'total':round(total['total'],3),'first_at':total['first_at'],'last':last,'pending_employee':state['pending_employee'] if state else None,'armed_at':state['armed_at'] if state else None,'last_card_uid':state['last_card_uid'] if state else None,'card_status':state['card_status'] if state else None,'card_seen_at':state['card_seen_at'] if state else None,'weighings':[dict(row) for row in rows]}))
@app.delete('/api/raw/last')
def delete_last_raw(request:Request,day:Optional[str]=None):
    require(request); selected=day or datetime.now().date().isoformat()
    with conn() as c:
        row=c.execute('SELECT id FROM raw_weighings WHERE work_date=? AND deleted=0 ORDER BY created_at DESC LIMIT 1',(selected,)).fetchone()
        if row: c.execute('UPDATE raw_weighings SET deleted=1 WHERE id=?',(row['id'],))
    return private(JSONResponse({'ok':True,'deleted':bool(row)}))
@app.post('/api/sync')
def sync(payload:SyncPayload,request:Request):
    require(request)
    with conn() as c:
        for e in payload.entries:
            existing=c.execute('SELECT updated_at FROM entries WHERE id=?',(e.id,)).fetchone()
            if not existing or e.updated_at>=existing['updated_at']:
                legacy=e.class1_boxes==0 and e.class1_trays==0 and e.raw_total==0 and (e.amount_a>0 or e.amount_b>0)
                class1=round(e.amount_a if legacy else e.class1_boxes*1.5+e.class1_trays*.125,3);raw=max(0,round(e.amount_a+e.amount_b if legacy else e.raw_total,3));class2=max(0,round(e.amount_b if legacy else raw-class1,3))
                c.execute('''INSERT INTO entries(id,date,crop,amount_a,amount_b,start,end,staff,updated_at,deleted,class1_boxes,class1_trays,raw_total) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET date=excluded.date,crop=excluded.crop,amount_a=excluded.amount_a,amount_b=excluded.amount_b,start=excluded.start,end=excluded.end,staff=excluded.staff,updated_at=excluded.updated_at,deleted=excluded.deleted,class1_boxes=excluded.class1_boxes,class1_trays=excluded.class1_trays,raw_total=excluded.raw_total''',(e.id,e.date,e.crop,class1,class2,e.start,e.end,len(e.employee_ids),e.updated_at,1 if e.deleted else 0,e.class1_boxes,e.class1_trays,raw))
                c.execute('DELETE FROM entry_employees WHERE entry_id=?',(e.id,));c.executemany('INSERT OR IGNORE INTO entry_employees(entry_id,employee_id) VALUES(?,?)',[(e.id,i) for i in e.employee_ids])
        rows=c.execute('SELECT * FROM entries WHERE updated_at > ? ORDER BY updated_at',(payload.since,)).fetchall() if payload.since else c.execute('SELECT * FROM entries ORDER BY updated_at').fetchall()
        data=[]
        for row in rows:
            item=dict(row);item['deleted']=bool(item['deleted']);item['employee_ids']=[r['employee_id'] for r in c.execute('SELECT employee_id FROM entry_employees WHERE entry_id=?',(item['id'],))];data.append(item)
    return private(JSONResponse({'entries':data,'server_time':datetime.utcnow().isoformat()+'Z'}))
@app.get('/api/export.xlsx')
def export_xlsx(request:Request):
    require(request); wb=Workbook(); ws=wb.active; ws.title='Ernteaufzeichnung'; ws.append(['Datum','Kultur','Rohware (kg)','Klasse 1 Schachteln','Klasse 1 Schalen 125g','Klasse 1 (kg)','Klasse 2 (kg)','Beginn','Ende','Mitarbeiter','Arbeitsdauer (h)','Personalstunden'])
    with conn() as c: rows=c.execute('SELECT * FROM entries WHERE deleted=0 ORDER BY date,start').fetchall()
    def duration(start,end):
        try:
            sh,sm=map(int,start.split(':')); eh,em=map(int,end.split(':')); mins=(eh*60+em)-(sh*60+sm); mins=mins+1440 if mins<0 else mins; return round(mins/60,2)
        except: return 0
    with conn() as c:
        for row in rows:
            dur=duration(row['start'],row['end']);names=', '.join(f"{x['number']} {x['name']}" for x in c.execute('SELECT e.number,e.name FROM employees e JOIN entry_employees ee ON ee.employee_id=e.id WHERE ee.entry_id=? ORDER BY e.number',(row['id'],)))
            ws.append([row['date'],row['crop'],row['raw_total'],row['class1_boxes'],row['class1_trays'],row['amount_a'],row['amount_b'],row['start'],row['end'],names,dur,round(dur*row['staff'],2)])
    ws.freeze_panes='A2'
    raw=wb.create_sheet('Himbeeren Rohware'); raw.append(['Arbeitstag','Uhrzeit','Mitarbeiternummer','Gewicht (kg)','Waagenstation'])
    with conn() as c: weighings=c.execute('SELECT work_date,created_at,employee_number,weight,station FROM raw_weighings WHERE deleted=0 ORDER BY created_at').fetchall()
    for item in weighings: raw.append([item['work_date'],item['created_at'][11:19],item['employee_number'],item['weight'],item['station']])
    raw.freeze_panes='A2';staff=wb.create_sheet('Mitarbeiter')
    staff.append(['Personalnummer','Name','Aktiv'])
    with conn() as c:
        for person in c.execute('SELECT number,name,active FROM employees WHERE deleted=0 ORDER BY number'):staff.append([person['number'],person['name'],'Ja' if person['active'] else 'Nein'])
    staff.freeze_panes='A2';wb.save(EXPORT); return private(FileResponse(EXPORT,filename='Ernteaufzeichnung.xlsx',media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'))
