@echo off
cd /d "%~dp0"
start "ErnteServer Launcher" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0ErnteLauncher.ps1"
