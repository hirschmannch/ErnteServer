@echo off
title ErnteServer Waage und NFC
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0waage_nfc_bridge.ps1"
echo.
echo Die Waagenstation wurde beendet. Bitte Waage und NFC-Leser pruefen.
pause
