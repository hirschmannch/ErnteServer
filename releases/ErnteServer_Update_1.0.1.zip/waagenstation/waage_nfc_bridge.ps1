param([string]$ServerUrl='http://127.0.0.1:8000',[string]$ComPort='COM3',[int]$BaudRate=19200,[string]$Station='waage-1')
$ErrorActionPreference='Stop'
$authPath=Join-Path (Split-Path $PSScriptRoot -Parent) 'auth.env'
$tokenLine=Get-Content -LiteralPath $authPath | Where-Object {$_ -match '^WAAGE_TOKEN='} | Select-Object -Last 1
$ScaleToken=($tokenLine -replace '^WAAGE_TOKEN=','').Trim()
if(-not $ScaleToken){throw 'WAAGE_TOKEN fehlt in C:\ErnteServer\auth.env'}
$headers=@{'X-Scale-Token'=$ScaleToken}
Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices;
public static class ACR122 {
 [DllImport("winscard.dll")] static extern int SCardEstablishContext(uint s,IntPtr a,IntPtr b,out IntPtr c);
 [DllImport("winscard.dll",CharSet=CharSet.Auto)] static extern int SCardListReaders(IntPtr c,string g,byte[] r,ref uint n);
 [DllImport("winscard.dll",CharSet=CharSet.Auto)] static extern int SCardConnect(IntPtr c,string r,uint sh,uint p,out IntPtr card,out uint active);
 [StructLayout(LayoutKind.Sequential)] struct IOREQ {public uint protocol;public uint length;}
 [DllImport("winscard.dll")] static extern int SCardTransmit(IntPtr card,ref IOREQ pci,byte[] send,int slen,IntPtr rp,byte[] recv,ref int rlen);
 [DllImport("winscard.dll")] static extern int SCardDisconnect(IntPtr card,uint d);
 [DllImport("winscard.dll")] static extern int SCardReleaseContext(IntPtr c);
 public static string ReadUid(){IntPtr ctx,card;uint n=0,protocol;if(SCardEstablishContext(2,IntPtr.Zero,IntPtr.Zero,out ctx)!=0)return null;try{if(SCardListReaders(ctx,null,null,ref n)!=0||n<2)return null;byte[] names=new byte[n];if(SCardListReaders(ctx,null,names,ref n)!=0)return null;string[] all=System.Text.Encoding.Default.GetString(names).Split(new[]{'\0'},StringSplitOptions.RemoveEmptyEntries);string reader=Array.Find(all,x=>x.IndexOf("ACR122",StringComparison.OrdinalIgnoreCase)>=0);if(reader==null&&all.Length>0)reader=all[0];if(reader==null||SCardConnect(ctx,reader,2,3,out card,out protocol)!=0)return null;try{byte[] cmd={0xFF,0xCA,0,0,0},recv=new byte[64];int len=recv.Length;IOREQ pci=new IOREQ{protocol=protocol,length=8};if(SCardTransmit(card,ref pci,cmd,cmd.Length,IntPtr.Zero,recv,ref len)!=0||len<4||recv[len-2]!=0x90||recv[len-1]!=0)return null;return BitConverter.ToString(recv,0,len-2).Replace("-","");}finally{SCardDisconnect(card,0);}}finally{SCardReleaseContext(ctx);}}
}
'@
function Send-Json([string]$Path,[hashtable]$Body){try{return Invoke-RestMethod -Uri($ServerUrl.TrimEnd('/')+$Path)-Method Post -Headers $headers -ContentType 'application/json' -Body($Body|ConvertTo-Json -Compress)-TimeoutSec 5}catch{Write-Host("Server nicht erreichbar: "+$_.Exception.Message)-ForegroundColor Red;return $null}}
$serial=[System.IO.Ports.SerialPort]::new($ComPort,$BaudRate,[System.IO.Ports.Parity]::None,8,[System.IO.Ports.StopBits]::One);$serial.ReadTimeout=100;$serial.Open()
Write-Host "Waage: $ComPort, $BaudRate Baud" -ForegroundColor Green;Write-Host 'NFC: ACR122U' -ForegroundColor Green;Write-Host 'Station laeuft. Dieses Fenster offen lassen.' -ForegroundColor Cyan
$buffer='';$weighing='';$lastUid=''
try{while($true){
 $uid=[ACR122]::ReadUid();if($uid-and$uid-ne$lastUid){$reply=Send-Json '/api/nfc/card' @{uid=$uid;station=$Station};if($reply.status-eq'assigned'){Write-Host("Karte erkannt: Mitarbeiter "+$reply.employee_number)-ForegroundColor Green}elseif($reply){Write-Host 'Unbekannte Karte: Mitarbeiternummer einmalig in der App eingeben.' -ForegroundColor Yellow}};$lastUid=if($uid){$uid}else{''}
 $buffer+=$serial.ReadExisting();while($buffer-match'^(.*?)(\r\n|\n|\r)'){$line=$matches[1].Trim();$buffer=$buffer.Substring($matches[0].Length);if($line-match'^Weighing\s+N:\s*#?\s*(\d+)'){$weighing=$matches[1]};if($line-match'^Net\s*:\s*([+-]?\d+(?:[\.,]\d+)?)\s*kg'){$weight=[double]::Parse(($matches[1]-replace',','.'),[Globalization.CultureInfo]::InvariantCulture);if($weight-gt 0){$eventId=if($weighing){"$Station-$weighing"}else{"$Station-$([guid]::NewGuid().ToString('N'))"};$reply=Send-Json '/api/scale/stable' @{weight=$weight;stable=$true;station=$Station;event_id=$eventId};if($reply.accepted){Write-Host("Gespeichert: {0:N3} kg, Mitarbeiter {1}"-f$weight,$reply.employee_number)-ForegroundColor Green}elseif($reply.reason-eq'employee_required'){Write-Host("Nicht gespeichert: zuerst Karte auflegen oder Mitarbeiternummer eingeben ({0:N3} kg)"-f$weight)-ForegroundColor Yellow}};$weighing=''}};Start-Sleep -Milliseconds 180
}}finally{if($serial.IsOpen){$serial.Close()}}
